classdef GoFa10 < RobotBaseClass

    properties(Access = public)              
    plyFileNameStem = 'GoFa10';
    end
    
    methods
      %% Define robot Function 
        function self = GoFa10(baseTr)
			self.CreateModel();
            if nargin < 1			
				baseTr = eye(4);				
            end
            
            

            self.model.base = self.model.base.T * baseTr * trotx(pi/2) * troty(pi/2); % initial placment of gofa10
            
            % Offset
            self.model.offset = [0,0,-pi/2,pi/1.5,0,pi/2,0];
            
            
            self.PlotAndColourRobot();   
            hold on
            
        end
    

        %% GoFa10 DH parameters 
        function CreateModel(self)            

            link(1) = Link([0      0.1519  0       pi/2   0]);
            link(2) = Link([0      0      -0.24365   0     0]);
            link(3) = Link([0      0      -0.21325  0      0]);
            link(4) = Link([0      0.11235   0       pi/2   0]);
            link(5) = Link([0      0.08535   0       -pi/2	0]);
            link(6) = Link([0      0.0819       0       0       0]);
            
            % Joint limits
            link(1).qlim = [-270 270]*pi/180;
            link(2).qlim = [-180 180]*pi/180; % joint limits chaged to not go through the table in "testRob" script
            link(3).qlim = [-225 85]*pi/180;
            link(4).qlim = [-180 180]*pi/180;
            link(5).qlim = [-180 180]*pi/180;
            link(6).qlim = [-270 270]*pi/180;
        
            self.model = SerialLink(link,'name',self.name);
            
        end
     
    end
    
end