% push button

clear;
close all;

button_pin = 'D4';

port = 'COM5';
board = 'Uno';

a = arduino;
go = 1;

while go == 1
    button_val = readDigitalPin(a, button_pin);
    display(button_val);
end




