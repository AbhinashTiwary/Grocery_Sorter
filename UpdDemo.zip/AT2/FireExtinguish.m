axis([-2,2,-2,2,0,2])


% The following code to place objects was taken from Lab 2 solution and
% applied to my case

hold on 

% Loading robot
r = LinearUR3;

% The following code for reading the ply file, setting the objects, and updating 
% human and fire extinguisher locations is taken from Gavin Pauls "R2D2 and a 
% Flying Monkey's Head: Loading Blender Models into Matlab" video and then applied 
% to my case

% Placing table
table = PlaceObject('Paintedtable.ply',[0,0,0]);
verts = [get(table,'Vertices'), ones(size(get(table,'Vertices'),1),1)] * trotz(pi/2);
set(table,'Vertices',verts(:,1:3))

% Placing fire extinguisher
[f,v,data] = plyread('PaintedExtinguisher.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
fireColours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
fire = trisurf(f,v(:,1)-0.1,v(:,2)+1.7, v(:,3)+0.35 ...
    ,'FaceVertexCData',fireColours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
fireVertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPointfire = sum(v)/fireVertexCount;
fireVerts = v - repmat(midPointfire,fireVertexCount,1);

% Create transfomation matrix
firePose = makehgtform('translate',[-0.1,1.7,0.35]);


% Placing person
[f,v,data] = plyread('PaintedHuman1.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
humanColours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
human = trisurf(f,v(:,1),v(:,2)+1.8, v(:,3) ...
    ,'FaceVertexCData',humanColours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
humanVertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPointhuman = sum(v)/humanVertexCount;
humanVerts = v - repmat(midPointhuman,humanVertexCount,1);

% Create transfomation matrix
humanPose = makehgtform('translate',[0,1.8,0.6]);



% Placing emergency stop
stop = PlaceObject('PaintedStop.ply',[1.8,-1.8,1]);

% Placing bricks
% The following code for reading the ply file, setting the bricks, and updating brick 
% locations is taken from Gavin Pauls "R2D2 and a Flying Monkey's Head: Loading 
% Blender Models into Matlab" video and then applied to my case

% Brick 1
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex1Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick1 = trisurf(f,v(:,1),v(:,2)+0.4, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex1Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick1VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint1 = sum(v)/brick1VertexCount;
brick1Verts = v - repmat(midPoint1,brick1VertexCount,1);

% Create transfomation matrix
brick1Pose = eye(4);


% Brick 2
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex2Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick2 = trisurf(f,v(:,1)-0.2,v(:,2)+0.4, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex2Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick2VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint2 = sum(v)/brick2VertexCount;
brick2Verts = v - repmat(midPoint2,brick2VertexCount,1);

% Create transfomation matrix
brick2Pose = eye(4);


% Brick 3
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex3Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick3 = trisurf(f,v(:,1)-0.4,v(:,2)+0.4, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex3Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick3VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint3 = sum(v)/brick3VertexCount;
brick3Verts = v - repmat(midPoint3,brick3VertexCount,1);

% Create transfomation matrix
brick3Pose = eye(4);


% Brick 4
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex4Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick4 = trisurf(f,v(:,1)-0.6,v(:,2)+0.4, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex4Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick4VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint4 = sum(v)/brick4VertexCount;
brick4Verts = v - repmat(midPoint4,brick4VertexCount,1);

% Create transfomation matrix
brick4Pose = eye(4);


% Brick 5
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex5Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick5 = trisurf(f,v(:,1)-0.8,v(:,2)+0.4, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex5Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick5VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint5 = sum(v)/brick5VertexCount;
brick5Verts = v - repmat(midPoint5,brick5VertexCount,1);

% Create transfomation matrix
brick5Pose = eye(4);


% Brick 6
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex6Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick6 = trisurf(f,v(:,1),v(:,2)-0.42, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex6Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick6VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint6 = sum(v)/brick6VertexCount;
brick6Verts = v - repmat(midPoint6,brick6VertexCount,1);

% Create transfomation matrix
brick6Pose = eye(4);


% Brick 7
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex7Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick7 = trisurf(f,v(:,1)-0.2,v(:,2)-0.42, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex7Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick7VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint7 = sum(v)/brick7VertexCount;
brick7Verts = v - repmat(midPoint7,brick7VertexCount,1);

% Create transfomation matrix
brick7Pose = eye(4);


% Brick 8
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex8Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick8 = trisurf(f,v(:,1)-0.4,v(:,2)-0.42, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex8Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick8VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint8 = sum(v)/brick8VertexCount;
brick8Verts = v - repmat(midPoint8,brick8VertexCount,1);

% Create transfomation matrix
brick8Pose = eye(4);


% Brick 9
[f,v,data] = plyread('HalfSizedRedGreenBrick.ply','tri');

% Scale from RGB 0-255 to RGB 0-1
vertex9Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

% Plots the surfaces of the brick
brick9 = trisurf(f,v(:,1)-0.6,v(:,2)-0.42, v(:,3)+0.52 ...
    ,'FaceVertexCData',vertex9Colours,'EdgeColor','interp','EdgeLighting','flat');

% Vertex count
brick9VertexCount = size(v,1);

% Remap brick vert matrix so it is the same size as if it where 
% get(brick,'Vertices')
midPoint9 = sum(v)/brick9VertexCount;
brick9Verts = v - repmat(midPoint9,brick9VertexCount,1);

% Create transfomation matrix
brick9Pose = eye(4);

% Placing floor, code taken from Lab Assesment 1 canvas page and adapted for
% my case
surf([-2,-2;2,2],[-2,2;-2,2],[0.01,0.01;0.01,0.01] ...
,'CData',imread('oakfloorhd.jpg'),'FaceColor','texturemap');

movFwFire = makehgtform('translate',[0,-0.0009,0.0005]);
movFwHuman = makehgtform('translate',[0,-0.0009,0]);

for i = 1:1000
    firePose = firePose * movFwFire;
    updFire = [firePose * [fireVerts,ones(fireVertexCount,1)]']';
    fire.Vertices = updFire(:,1:3);
    humanPose = humanPose * movFwHuman;
    updHuman = [humanPose * [humanVerts,ones(humanVertexCount,1)]']';
    human.Vertices = updHuman(:,1:3);
    drawnow();   
end