axis([-0.5,0.5,-0.5,0.5,0,1])
hold on
r = DobotMagician

view(3);

steps = 90;
 
for i = 1:3

% initial robot state
T1_r = transl(0.2594,0,0.08071) *trotz(pi);
q1_r = r.model.ikcon(T1_r);

% move 2 pose
T2_r = transl(0.4,0,0.08071) *trotz(pi);
q2_r = r.model.ikcon(T2_r);

robTraj1 = jtraj(q1_r,q2_r,steps);

for i = 1:steps
    r.model.animate(robTraj1(i,:));
    drawnow();
end


% move 1 pose
T2_r = transl(0.4,0,0.08071) *trotz(pi);
q2_r = r.model.ikcon(T2_r);

% move 2 pose
T3_r = transl(0.2,-0.2,0.08071) *trotz(pi);
q3_r = r.model.ikcon(T3_r);

robTraj2 = jtraj(q2_r,q3_r,steps);

for i = 1:steps
    r.model.animate(robTraj2(i,:));
    drawnow();
end

% move 2 pose
T3_r = transl(0.2,-0.2,0.08071) *trotz(pi);
q3_r = r.model.ikcon(T3_r);

% move 3 pose
T4_r = transl(0.2,-0.2,0.25) *trotz(pi);
q4_r = r.model.ikcon(T4_r);

robTraj3 = jtraj(q3_r,q4_r,steps);

for i = 1:steps
    r.model.animate(robTraj3(i,:));
    drawnow();
end


% move 3 pose
T4_r = transl(0.2,-0.2,0.25) *trotz(pi);
q4_r = r.model.ikcon(T4_r);

% move 4 pose
T5_r = transl(0.2,0.2,0.25) *trotz(pi);
q5_r = r.model.ikcon(T5_r);

robTraj4 = jtraj(q4_r,q5_r,steps);

for i = 1:steps
    r.model.animate(robTraj4(i,:));
    drawnow();
end


% move 4 pose
T5_r = transl(0.2,0.2,0.25) *trotz(pi);
q5_r = r.model.ikcon(T5_r);

% initial robot state
T1_r = transl(0.2594,0,0.08071) *trotz(pi);
q1_r = r.model.ikcon(T1_r);

robTraj5 = jtraj(q5_r,q1_r,steps);

for i = 1:steps
    r.model.animate(robTraj5(i,:));
    drawnow();
end

end